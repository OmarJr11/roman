# roman
Convertir un número romano en decimal usando Flex y Bison

Instegrantes: 
	Anderson Arciniegas 27481456
	Omar Gonzalez 27244029

./makefile.sh 		para crear los archivos ejecutables
./roman XIVV 		para correr el programa 
